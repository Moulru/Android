package my.nametag_20141488;

import android.content.pm.ActivityInfo;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    ImageView imageView;
    TextView textView_ph;
    TextView textView_em;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);

        setContentView(R.layout.activity_main);

        imageView = (ImageView) findViewById(R.id.logo);
        textView_ph = (TextView) findViewById(R.id.textPhone);
        textView_em = (TextView) findViewById(R.id.textEmail);

        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(),"안녕하세요. Android Stu의 박준호 입니다.",Toast.LENGTH_LONG).show();
            }
        });

        textView_ph.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(),"010.1234.5678로 전화걸기",Toast.LENGTH_SHORT).show();
            }
        });

        textView_em.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(),"qkrwnsgh777@naver.com로 이메일 전송",Toast.LENGTH_SHORT).show();
            }
        });
    }
}
