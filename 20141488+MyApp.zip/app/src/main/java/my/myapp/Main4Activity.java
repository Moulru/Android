package my.myapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.widget.EditText;
import android.widget.Toast;

public class Main4Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);

        // xml의 에디트 텍스트 뷰를 참조하기위한 방법
        // View view = findViewById(); 형식으로 적어도 되지만, 좀더 명확하게 EditText라는 클래스로 주는것이 좋다
        // View는 안드로이드의 최상위 클래스, EditText는 View클래스의 자식클래스이다
        // EditText클래스로 만들었기 때문에 뒤에도 (EditText)를 적어 형변환 시켜준다
        EditText view = (EditText) findViewById(R.id.addr);
        EditText view2 = (EditText) findViewById(R.id.name);

        view.setText("대전 동구 용운동");
        view2.setText("박준호");

        // Toast 메세지 띄우는 방법
        // Toast.makeText(띄울곳,띄울메시지,띄울시간).show();
        // show()를 적어야 화면에 띄워준다
        Toast.makeText(this,"수정 성공",Toast.LENGTH_LONG).show();
    }
}
