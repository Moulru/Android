package my.day11_1;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

public class RegisterActivity extends AppCompatActivity {

    DBmanager dbManger;
    // SQLiteDatabase sqLiteDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        setTitle("고객정보");

        dbManger = new DBmanager(this);
        // sqLiteDatabase = dbManger.getWritableDatabase();

        Intent it = getIntent();
        String str_name = it.getStringExtra("it_name");
        String str_sex  = it.getStringExtra("it_sex");
        String str_mag1 = it.getStringExtra("it_msg1");
        String str_mag2 = it.getStringExtra("it_msg2");

        /////////////////////////////////////////////////////////////////////////////
        boolean result = dbManger.insertData(str_name,str_sex,str_mag1,str_mag2);

        AlertDialog.Builder builder;

        if(result) {
            builder = new AlertDialog.Builder(this);
            builder.setTitle("데이터 입력 여부");
            builder.setMessage("입력 성공");
            builder.setPositiveButton("확인",null);
            AlertDialog dialog = builder.create();
            dialog.show();
        }else {
            builder = new AlertDialog.Builder(this);
            builder.setTitle("데이터 입력 여부");
            builder.setMessage("입력 실패");
            builder.setPositiveButton("확인",null);
            AlertDialog dialog = builder.create();
            dialog.show();
        }
        /////////////////////////////////////////////////////////////////////////////

        TextView tv_name   = (TextView)findViewById(R.id.name);
        TextView tv_gender = (TextView)findViewById(R.id.gender);
        TextView tv_msg    = (TextView)findViewById(R.id.msg);

        tv_name.append(": " + str_name);
        tv_gender.append(": " + str_sex);
        tv_msg.append(": " + str_mag1 + " " + str_mag2);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Intent intent = null;
        switch (item.getItemId()) {
            case R.id.action_settings1 :    // 홈 메뉴 클릭시
                intent = new Intent(this, MainActivity.class);
                break;
            case R.id.action_settings2:     // 고객 등록 메뉴
                intent = new Intent(this, MainActivity.class);
                break;
            case R.id.action_settings3:     // 고객 현황 메뉴
                intent = new Intent(this, CustomerListActivity.class);
                break;
        }
        startActivity(intent);
        finish();
        return true;
    }

    public void goBack(View v) {
        Intent it    = new Intent(this, MainActivity.class);
        startActivity(it);
        finish();
    }
}
