package my.day11_1;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteException;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class CustomerDetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_detail);
        // 고객 정보를 추가할 전체 레이아웃 인식
        LinearLayout layout = (LinearLayout)findViewById(R.id.detail);

        //정보 추출할 인텐트 호출
        Intent intent = getIntent();
        // 인텐트로 상세 조회할 성명값을 추출함
        String result_name = intent.getStringExtra("name");
        String name = "";


        try {
            DBmanager dbManager = new DBmanager(this);
            Cursor cursor = dbManager.selectData(result_name);

            if (cursor.moveToNext()) {
                name = cursor.getString(cursor.getColumnIndex("name"));
                String gender = cursor.getString(cursor.getColumnIndex("gender"));
                String sms = cursor.getString(cursor.getColumnIndex("sms"));
                String email = cursor.getString(cursor.getColumnIndex("email"));

                //레이아웃에 추가할 고객정보(성명)을 위한 텍스트 뷰 생성
                TextView textView = new TextView(this);
                textView.append(name);
                textView.setTextSize(20);
                textView.setTextColor(Color.YELLOW);
                textView.setBackgroundColor(Color.BLUE);
                layout.addView(textView);

                //레이아웃에 추가할 성별, 수신여부를  위한 텍스트 뷰 생성
                TextView textView2 = new TextView(this);
                textView2.append(gender + "\n");
                textView2.append(sms + "   " + email + "\n");
                layout.addView(textView2);

            }
            cursor.close();
            dbManager.close();
        }catch (SQLiteException e){
            TextView textView = new TextView(this);
            textView.append("등록된 고객이 없습니다.");
            textView.append(e.getMessage());
            layout.addView(textView);
        }


        // 수정 ,삭제 버튼에 리스너 부착

        final	Button	update	=	(Button)findViewById(R.id.update);
        /////////////////////////////////////////////////////////////
        update.setTag(name);	//	수정화면으로	넘어갈	때,	인텐트가	가져갈	데이터를	tag로	지정함
        /////////////////////////////////////////////////////////////
        update.setOnClickListener(new	View.OnClickListener()	{
            @Override
            public	void	onClick(View v)	{
                Intent	intent1		=	new	Intent(CustomerDetailActivity.this,	CustomerModActivity.class);
                intent1.putExtra("name",	update.getTag().toString());
                startActivity(intent1);
                finish();
            }
        });	//수정버튼	이벤트	끝--------------------------------------------
        final Button delete	=(Button)findViewById(R.id.delete);
        /////////////////////////////////////////////////////////////
        delete.setTag(name);
        /////////////////////////////////////////////////////////////
        delete.setOnClickListener(new	View.OnClickListener()	{
            @Override
            public	void	onClick(View	v)	{
                Intent	intent1		=	new	Intent(CustomerDetailActivity.this,	CustomerDelActivity.class);
                intent1.putExtra("name",	update.getTag().toString());
                startActivity(intent1);
                finish();
            }
        });		//삭제버튼	이벤트	끝--------------------------------------------

        // 되돌아가기
        final Button undo = (Button)findViewById(R.id.und0);
        undo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1 = new Intent(CustomerDetailActivity.this,CustomerListActivity.class);
                startActivity(intent1);
                finish();
            }
        });

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Intent intent = null;
        switch (item.getItemId()) {
            case R.id.action_settings1 :    // 홈 메뉴 클릭시
                intent = new Intent(this,MainActivity.class);
                break;
            case R.id.action_settings2:     // 고객 등록 메뉴
                intent = new Intent(this,MainActivity.class);
                break;
            case R.id.action_settings3:     // 고객 현황 메뉴
                intent = new Intent(this, CustomerListActivity.class);
                break;
        }
        startActivity(intent);
        finish();
        return true;
    }
}
