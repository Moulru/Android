package my.day11_1;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteException;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class CustomerModActivity extends AppCompatActivity {

    DBmanager dbManager;
    String data;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_mod);
        setTitle("고객정보 수정");

        try {

            dbManager = new DBmanager(this);

            Intent intent = getIntent();
            data = intent.getStringExtra("name");

            ///////////////////////////////////////////////////////////
            // 1. 이름과 일치하는 데이터를 모두 불러온다..
            Cursor cursor = dbManager.selectData(data);
            if (cursor.moveToNext()) {
                String dbname = cursor.getString(cursor.getColumnIndex("name"));
                String dbgender = cursor.getString(cursor.getColumnIndex("gender"));
                String dbsms = cursor.getString(cursor.getColumnIndex("sms"));
                String dbemail = cursor.getString(cursor.getColumnIndex("email"));

                // 2. 꺼낸 정보를 일단 수정할 뷰로 출력하기.
                EditText editText = (EditText) findViewById(R.id.name);
                editText.setText(dbname);

                RadioButton radioButton = null;
                if (dbgender.equals("남")) {
                    radioButton = (RadioButton) findViewById(R.id.male);
                    radioButton.setChecked(true);
                } else if (dbgender.equals("여")) {
                    radioButton = (RadioButton) findViewById(R.id.female);
                    radioButton.setChecked(true);
                }

                CheckBox checkBox = (CheckBox) findViewById(R.id.msg1);
                CheckBox checkBox1 = (CheckBox) findViewById(R.id.msg2);
                if (dbsms.equals("sms") || dbsms.equals("SMS")) {
                    checkBox.setChecked(true);
                }
                if (dbemail.equals("e-mail") || dbemail.equals("E-MAIL")) {
                    checkBox1.setChecked(true);
                }

            }
            cursor.close();
            dbManager.close();
        }catch (SQLiteException e){
            TextView textView = new TextView(this);
            textView.append("등록된 고객이 없습니다.");
            textView.append(e.getMessage());
        }
        //////////////////////////////////////////////////////////

        Button button = (Button)findViewById(R.id.ok);
        Button button1 = (Button)findViewById(R.id.cancle);

        // 수정 ok 버튼
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 3. 새로 수정된 정보를 읽어와서
                // 새이름 추출
                EditText editText = (EditText)findViewById(R.id.name);
                String newName = editText.getText().toString();
                // 새성별 추출
                RadioGroup rg_sex = (RadioGroup)findViewById(R.id.radiogroup_gender);
                String newGender = "";
                if (rg_sex.getCheckedRadioButtonId() == R.id.male) {
                    newGender = "남";
                }
                if (rg_sex.getCheckedRadioButtonId() == R.id.female) {
                    newGender = "여";
                }
                // 새수신여부 추출
                CheckBox   chk_msg1 = (CheckBox)findViewById(R.id.msg1);
                CheckBox   chk_msg2 = (CheckBox)findViewById(R.id.msg2);
                String newSms ="";
                String newEmail="";
                if(chk_msg1.isChecked()) {
                    newSms = chk_msg1.getText().toString();
                }
                if(chk_msg2.isChecked()) {
                    newEmail = chk_msg2.getText().toString();
                }

                // 4. 데이터베이스에 update하기
                boolean result = dbManager.updateData(newName, newGender, newSms , newEmail, data );

                if(result){
                    Toast.makeText(getApplicationContext(),"수정성공!", Toast.LENGTH_LONG).show();
                }else{
                    Toast.makeText(getApplicationContext(),"수정실패!", Toast.LENGTH_LONG).show();
                }
                // dbManager.close();
                // 5. 다시 고객현황화면으로 모든 레코드 불러오기
                Intent intent = new Intent(CustomerModActivity.this, CustomerDetailActivity.class);
                intent.putExtra("name", newName);
                startActivity(intent);
                finish();

            }
        });

        //취소 버튼
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CustomerModActivity.this, CustomerListActivity.class);
                startActivity(intent);
                finish();
            }
        });

    }
}
