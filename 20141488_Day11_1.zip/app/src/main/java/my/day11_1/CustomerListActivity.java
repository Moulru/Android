package my.day11_1;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

public class CustomerListActivity extends AppCompatActivity {

    DBmanager dBmanager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_list);

        dBmanager = new DBmanager(this);

        // main_layout 초기화
        LinearLayout mainlayout = (LinearLayout)findViewById(R.id.main_layout);

        ///////////////////////////////////////////////////////////////////////
        Cursor cursor = dBmanager.selectAll();


        while(cursor.moveToNext()) {

            String name = cursor.getString(cursor.getColumnIndex("name"));
            String gender = cursor.getString(cursor.getColumnIndex("gender"));
            String sms = cursor.getString(cursor.getColumnIndex("sms"));
            String email = cursor.getString(cursor.getColumnIndex("email"));

            // LinearLayout 동적생성 + 방향성 설정
            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL);

            // TextView1 동적생성 + 텍스트크기 조정
            final TextView textView1 = new TextView(this);
            textView1.setTextSize(30);
            textView1.setText(name);

            // TextView1에 DetailActivity로 넘어갈 온클릭 속성 추가
            textView1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(getApplicationContext(),CustomerDetailActivity.class);
                    intent.putExtra("name",textView1.getText().toString());
                    startActivity(intent);
                    finish();
                }
            });

            TextView textView2 = new TextView(this);
            textView2.setText(gender + "\n");
            textView2.append(sms + " " + email + "\n");

            // 동적생성한 Layout에 TextView 추가
            layout.addView(textView1);
            layout.addView(textView2);

            // main_layout에 동적생성한 layout 추가
            mainlayout.addView(layout);

        }


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Intent intent = null;
        switch (item.getItemId()) {
            case R.id.action_settings1 :    // 홈 메뉴 클릭시
                intent = new Intent(this, MainActivity.class);
                break;
            case R.id.action_settings2:     // 고객 등록 메뉴
                intent = new Intent(this, MainActivity.class);
                break;
            case R.id.action_settings3:     // 고객 현황 메뉴
                intent = new Intent(this, CustomerListActivity.class);
                break;
        }
        startActivity(intent);
        finish();
        return true;
    }

}
