package my.day11_1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Toast;

public class CustomerDelActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent intent = getIntent();
        String name = intent.getStringExtra("name");
        DBmanager dbManager = new DBmanager(this);
        boolean result = dbManager.deleteData(name);

        if(result){
            Intent intent1 = new Intent(CustomerDelActivity.this, CustomerListActivity.class);
            startActivity(intent1);
            finish();
            Toast.makeText(getApplicationContext(),"삭제 성공", Toast.LENGTH_LONG).show();
        }else{
            Toast.makeText(getApplicationContext(),"삭제 실패", Toast.LENGTH_LONG).show();
        }
    }
}
