package my.day11_1;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.strictmode.SqliteObjectLeakedViolation;

public class DBmanager extends SQLiteOpenHelper {



    public DBmanager(Context context) {
        super(context, "myDB", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL("create table customers (name text, gender text, sms text, email text);");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    // 고객 정보 저장하는 메소드 정의하기 (레코드 추가하기)
    public boolean insertData(String name, String gender, String sms, String email) {

        SQLiteDatabase sqLiteDatabase = getWritableDatabase();

        ContentValues contentValues = new ContentValues();
        contentValues.put("name",name);
        contentValues.put("gender",gender);
        contentValues.put("sms",sms);
        contentValues.put("email",email);

        // sqLite 전용 메소드 사용
        sqLiteDatabase.insert("customers",null,contentValues);
        return true;
    }

    // 조회 하기 메소드
    public Cursor selectAll() {
        SQLiteDatabase sqLiteDatabase = getReadableDatabase();
        Cursor cursor = sqLiteDatabase.rawQuery("select * from customers",null);

        return cursor;
    }

    public Cursor selectData(String name) {
        SQLiteDatabase sqLiteDatabase = getReadableDatabase();
        Cursor cursor = sqLiteDatabase.rawQuery("select * from customers where name = '"+name+"'",null);

        return cursor;
    }

    // 수정 하기 메소드
    public	boolean	updateData(String	newName,	String	gender,	String	sms,	String	email,		String	name)				{
        SQLiteDatabase	sqLiteDatabase	=	getWritableDatabase();
        ContentValues	contentValues	=	new	ContentValues();
        contentValues.put("name",	newName);
        contentValues.put("gender",	gender);
        contentValues.put("sms",	sms);
        contentValues.put("email",	email);
        sqLiteDatabase.update("customers",contentValues,"name=?",new	String[]{name});
        return	true;
    }

    // 삭제 메소드
    public	boolean	deleteData(String	name)	{
        SQLiteDatabase	sqLiteDatabase	=	getWritableDatabase();
        sqLiteDatabase.execSQL("DELETE	FROM	customers	WHERE	name	=	'"+name+"'");
        return	true;
    }
}