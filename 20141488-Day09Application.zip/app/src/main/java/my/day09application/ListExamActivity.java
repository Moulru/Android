package my.day09application;

import android.app.ListActivity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class ListExamActivity extends ListActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // setContentView(R.layout.activity_list_exam);

        // 1. 문자열 배열 정의
        String [] data = {"사과", "딸기", "바나나", "포도", "오렌지", "수박", "망고", "참외", "키위", "귤"};

        // 2. ArrayAdapter 객체 생성 (배열이기에 arrayadaper)
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,data);
        // ArrayAdapter<형식> arrayAdapter = new ArrayAdapter<형식동일하게>(표시할 액티비티, 사용할 레이아웃, 배열)

        // 3. ListView 와 어뎁터 연결
        setListAdapter(arrayAdapter);
    }

    // 4. 이벤트처리: OnListItemClick 메소드 오버라이드
    @Override
    protected void onListItemClick(ListView l, View v, int position, long id) {
        super.onListItemClick(l, v, position, id);

        String value = (String)getListAdapter().getItem(position);
        // 리스트에 담긴 스트링 문자열 꺼내서 value에 저장

        Toast.makeText(getApplicationContext(),"좋아하는 과일은: "+value,Toast.LENGTH_SHORT).show();
    }
}
